/*
2nd Method
*/

import java.util.Scanner;
public class NumberAdder2{
	public static int  addNumbers(int a, int b){
		return (a+b);
	}
	public static void main(String arg[]){
		Scanner in = new Scanner(System.in);
		int one = in.nextInt();
		int two = in.nextInt();
		System.out.println(NumberAdder2.addNumbers(one,two));
	}
}
