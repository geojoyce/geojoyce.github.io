/*
Author:Joyce George
Exercise:1
Question:1
*/

import java.util.Scanner;
public class One{
	public static void  checkNumber(int a){
		    if (a >= 0)
		    if (a == 0)
        System.out.println("first string");
	else System.out.println("second string");
	System.out.println("third string");
	}
	public static void main(String arg[]){
		Scanner in = new Scanner(System.in);
		int number = in.nextInt();
		
		One.checkNumber(number);
	}
}
