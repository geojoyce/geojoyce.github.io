/*
1st Method
*/

import java.util.Scanner;
public class NumberAdder{
	public static void main(String arg[]){
		Scanner in = new Scanner(System.in);
		
		System.out.print("1st Number: ");
		int one = in.nextInt();
		 
		System.out.print("2nd Number: ");
		int two = in.nextInt();
		
		int result = one + two;
		System.out.println("result = " + result);
	}
}